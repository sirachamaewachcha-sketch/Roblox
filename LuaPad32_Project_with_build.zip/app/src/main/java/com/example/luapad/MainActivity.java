package com.example.luapad;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    LinearLayout root;
    EditText editor, nameBox;
    TextView output;
    File scriptsDir;
    boolean stopped = false;

    int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        scriptsDir = new File(getFilesDir(), "scripts");
        if (!scriptsDir.exists()) scriptsDir.mkdirs();

        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(16), dp(14), dp(16));
        root.setBackgroundColor(0xFF10131B);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("LuaPad32");
        title.setTextSize(26);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(0xFF72E6C1);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Lua script workspace • local save • demo runner");
        subtitle.setTextColor(0xFFB8C1D1);
        subtitle.setPadding(0, dp(4), 0, dp(12));
        root.addView(subtitle);

        nameBox = new EditText(this);
        nameBox.setSingleLine(true);
        nameBox.setHint("Script name (e.g. test)");
        nameBox.setTextColor(0xFFFFFFFF);
        nameBox.setHintTextColor(0xFF8993A5);
        nameBox.setBackgroundColor(0xFF202634);
        root.addView(nameBox, params(-1, -2));

        editor = new EditText(this);
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setMinLines(10);
        editor.setTextSize(14);
        editor.setTypeface(Typeface.MONOSPACE);
        editor.setTextColor(0xFFF1F5F9);
        editor.setHintTextColor(0xFF8993A5);
        editor.setHint("-- Write Lua here\\nprint('Hello world')");
        editor.setPadding(dp(10), dp(10), dp(10), dp(10));
        editor.setBackgroundColor(0xFF202634);
        LinearLayout.LayoutParams ep = params(-1, dp(240));
        ep.topMargin = dp(10);
        root.addView(editor, ep);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(row1, params(-1, -2));
        addButton(row1, "▶ Run demo", v -> runDemo());
        addButton(row1, "■ Stop", v -> { stopped = true; log("Stopped."); });
        addButton(row1, "Save", v -> saveScript());

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(row2, params(-1, -2));
        addButton(row2, "Scripts", v -> showScripts());
        addButton(row2, "Clear", v -> { editor.setText(""); log("Editor cleared."); });

        TextView outTitle = new TextView(this);
        outTitle.setText("Output");
        outTitle.setTextColor(0xFF72E6C1);
        outTitle.setTextSize(16);
        outTitle.setPadding(0, dp(12), 0, dp(4));
        root.addView(outTitle);

        output = new TextView(this);
        output.setText("Ready. Run demo only parses simple print('text') lines.");
        output.setTextColor(0xFFD5DCEC);
        output.setTextSize(13);
        output.setTypeface(Typeface.MONOSPACE);
        output.setPadding(dp(10), dp(10), dp(10), dp(10));
        output.setBackgroundColor(0xFF202634);
        root.addView(output, params(-1, -2));

        TextView warning = new TextView(this);
        warning.setText("Note: this is not a full Lua VM and does not execute scripts inside Roblox.");
        warning.setTextColor(0xFFFFC46B);
        warning.setPadding(0, dp(12), 0, 0);
        root.addView(warning);
    }

    LinearLayout.LayoutParams params(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    void addButton(LinearLayout parent, String label, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setOnClickListener(click);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1f);
        p.setMargins(dp(2), dp(6), dp(2), dp(2));
        parent.addView(b, p);
    }

    void log(String s) { output.setText(s); }

    void runDemo() {
        stopped = false;
        String code = editor.getText().toString();
        StringBuilder result = new StringBuilder();
        Pattern p = Pattern.compile("^\\s*print\\s*\\(\\s*(['\"])(.*?)\\1\\s*\\)\\s*;?\\s*$");
        String[] lines = code.split("\\n");
        int recognized = 0;
        for (String line : lines) {
            if (stopped) { result.append("Stopped.\\n"); break; }
            Matcher m = p.matcher(line);
            if (m.matches()) {
                result.append(m.group(2)).append("\\n");
                recognized++;
            } else if (!line.trim().isEmpty() && !line.trim().startsWith("--")) {
                result.append("[demo] unsupported line: ").append(line.trim()).append("\\n");
            }
        }
        if (recognized == 0 && result.length() == 0) result.append("No supported print() lines found.");
        log(result.toString());
    }

    String safeName(String name) {
        String n = name.trim().replaceAll("[^A-Za-z0-9_ -]", "_").replace(' ', '_');
        if (n.isEmpty()) n = "script";
        return n.endsWith(".lua") ? n : n + ".lua";
    }

    void saveScript() {
        String filename = safeName(nameBox.getText().toString());
        try (FileOutputStream fos = new FileOutputStream(new File(scriptsDir, filename))) {
            fos.write(editor.getText().toString().getBytes("UTF-8"));
            log("Saved: " + filename);
        } catch (Exception e) { log("Save failed: " + e.getMessage()); }
    }

    void showScripts() {
        File[] files = scriptsDir.listFiles((d, n) -> n.endsWith(".lua"));
        if (files == null || files.length == 0) {
            new AlertDialog.Builder(this).setTitle("Saved scripts").setMessage("No saved scripts yet.")
                .setPositiveButton("OK", null).show();
            return;
        }
        Arrays.sort(files, Comparator.comparing(File::getName));
        String[] names = new String[files.length];
        for (int i=0; i<files.length; i++) names[i] = files[i].getName();
        new AlertDialog.Builder(this).setTitle("Open saved script").setItems(names, (dialog, which) -> {
            File selected = files[which];
            try {
                byte[] data = new byte[(int)selected.length()];
                try (FileInputStream in = new FileInputStream(selected)) { in.read(data); }
                editor.setText(new String(data, "UTF-8"));
                nameBox.setText(selected.getName().replaceFirst("\\.lua$", ""));
                log("Loaded: " + selected.getName());
            } catch (Exception e) { log("Load failed: " + e.getMessage()); }
        }).setNeutralButton("Delete", (dialog, which) -> chooseDelete(files, names)).setNegativeButton("Cancel", null).show();
    }

    void chooseDelete(File[] files, String[] names) {
        new AlertDialog.Builder(this).setTitle("Delete script").setItems(names, (d, which) -> {
            boolean ok = files[which].delete();
            log(ok ? "Deleted: " + names[which] : "Delete failed.");
        }).setNegativeButton("Cancel", null).show();
    }
}
